import { getCustomRepository } from "typeorm";
import { PriceGroupRepository } from "../../repositories/PriceGroupRepository";
import { BooksRepositories } from "../../repositories/BooksRepositories";

export class DeletePriceGroupService {
  async execute(id: number): Promise<string> {
    const repo = getCustomRepository(PriceGroupRepository);
    const booksRepo = getCustomRepository(BooksRepositories);

    const group = await repo.findOne(id);
    if (!group) throw new Error("Grupo de precificação não encontrado.");

    // evita remoção se existirem livros associados
    // assumimos que TypeORM criou a coluna pricegroupId em books
    const linkedCount = await booksRepo
      .createQueryBuilder("book")
      .where("book.pricegroupId = :id", { id })
      .getCount();

    if (linkedCount > 0) {
      throw new Error(`Não é possível remover: existem ${linkedCount} livro(s) associados a este grupo.`);
    }

    await repo.remove(group);
    return `Grupo de precificação "${group.name}" (id: ${group.id}) removido com sucesso.`;
  }
}
