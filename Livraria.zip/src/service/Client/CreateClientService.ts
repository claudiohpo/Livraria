import { getCustomRepository } from "typeorm";
import { ClientsRepositories } from "../../repositories/ClientsRepositories";
import { IClientRequest } from "../../Interface/IClientInterface";

