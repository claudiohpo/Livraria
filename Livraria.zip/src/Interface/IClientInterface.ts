interface IClientRequest {
    id?: number;
    name: string;
    email: string;
    password: string;
    cpf: string;
    phone: string;
    birthdaydate: Date;
    gender: string;
}

export {IClientRequest};