export interface ICategoryRequest {
  name: string;
  description?: string;
  active?: boolean;
}